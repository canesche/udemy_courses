#ifndef PEIXE_H
#define PEIXE_H

#include <string>
using namespace std;

class Peixe {
    public:
        Peixe();
        virtual ~Peixe();
        void setNome(const string nome);
        void setIdade(const int idade);
        void setAguaDoce(const bool aguaDoce);
        const string getNome();
        const int getIdade();
        const string isAguaDoce();
    private:
        string nome;
        int idade;
        bool aguaDoce;
};

#endif