#include "Cachorro.h"

#include <iostream>
#include <string>

using namespace std;

Cachorro::Cachorro(){}

Cachorro::~Cachorro(){
    cout << "Objeto cachorro destruido" << endl;
}

void Cachorro::setNome(const string nome) {
    this->nome = nome;
}

void Cachorro::setIdade(const int idade) {
    this->idade = idade;
}

void Cachorro::setPatas(const int patas) {
    this->patas = patas;
}

const string Cachorro::getNome() {
    return nome;
}

const int Cachorro::getIdade() {
    return idade;
}

const int Cachorro::getPatas() {
    return patas;
}