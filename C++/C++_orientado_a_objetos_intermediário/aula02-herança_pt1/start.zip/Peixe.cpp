#include "Peixe.h"

#include <iostream>
#include <string>

using namespace std;

Peixe::Peixe() {}

Peixe::~Peixe() {
    cout << "Objeto peixe destruido" << endl;
}

void Peixe::setNome(const string nome) {
    this->nome = nome;
}

void Peixe::setIdade(const int idade) {
    this->idade = idade;
}

void Peixe::setAguaDoce(const bool aguaDoce) {
    this->aguaDoce = aguaDoce;
}

const string Peixe::getNome() {
    return nome;
}

const int Peixe::getIdade() {
    return idade;
}

const string Peixe::isAguaDoce() {
    if (aguaDoce)
        return "Sim";
    else
        return "Nao";
}