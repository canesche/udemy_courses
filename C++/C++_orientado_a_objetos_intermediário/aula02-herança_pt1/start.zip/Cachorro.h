#ifndef CACHORRO_H
#define CACHORRO_H

#include <string>
using namespace std;

class Cachorro {
    public:
        Cachorro();
        virtual ~Cachorro();
        void setNome(const string Nome);
        void setIdade(const int idade);
        void setPatas(const int patas);
        const string getNome();
        const int getIdade();
        const int getPatas();
    private:
        string nome;
        int idade;
        int patas;
};

#endif